import os
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from dl_client import DL

app = FastAPI(title="Motor UI API")
dl = DL()

# Serve static React build if present (when running as a snap)
static_dir = os.getenv("STATIC_DIR")
if static_dir and os.path.isdir(static_dir):
    app.mount("/", StaticFiles(directory=static_dir, html=True), name="static")

class State(BaseModel):
    motorEnable: bool = Field(..., description="Enable/disable motor")
    motorSpeed: int   = Field(..., ge=0, le=10000, description="Motor speed (int)")

@app.get("/api/state", response_model=State)
def get_state():
    try:
        en, sp = dl.read_state()
        return {"motorEnable": en, "motorSpeed": sp}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/state", response_model=State)
def set_state(body: State):
    try:
        dl.write_enable(body.motorEnable)
        dl.write_speed(body.motorSpeed)
        en, sp = dl.read_state()
        return {"motorEnable": en, "motorSpeed": sp}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
