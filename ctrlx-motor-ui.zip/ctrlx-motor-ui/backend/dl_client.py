import os
from typing import Tuple

from datalayer.client import Client
from datalayer.system import System
from datalayer.variant import Variant
from datalayer.result import Result

_MOTOR_ENABLE = "plc/app/Application/sym/PLC_PRG/motorEnable"
_MOTOR_SPEED  = "plc/app/Application/sym/PLC_PRG/motorSpeed"

class DL:
    def __init__(self):
        self._sys = System("")
        self._sys.start(False)
        conn = os.getenv("DL_CONNECTION", "ipc://")
        self._client: Client = self._sys.factory().create_client(conn)

    def close(self):
        if self._client is not None:
            self._client.close()
        self._sys.stop(False)

    def read_state(self) -> Tuple[bool, int]:
        r1, v1 = self._client.read_sync(_MOTOR_ENABLE)
        if r1 != Result.OK:
            raise RuntimeError(f"Read failed: {r1} @ {_MOTOR_ENABLE}")
        motor_enable = v1.get_bool8()

        r2, v2 = self._client.read_sync(_MOTOR_SPEED)
        if r2 != Result.OK:
            raise RuntimeError(f"Read failed: {r2} @ {_MOTOR_SPEED}")
        motor_speed = v2.get_int32()

        return motor_enable, motor_speed

    def write_enable(self, value: bool):
        v = Variant()
        v.set_bool8(value)
        r = self._client.write_sync(_MOTOR_ENABLE, v)
        if r != Result.OK:
            raise RuntimeError(f"Write failed: {r} @ {_MOTOR_ENABLE}")

    def write_speed(self, value: int):
        v = Variant()
        v.set_int32(value)
        r = self._client.write_sync(_MOTOR_SPEED, v)
        if r != Result.OK:
            raise RuntimeError(f"Write failed: {r} @ {_MOTOR_SPEED}")
