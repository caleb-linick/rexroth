# ctrlx-motor-ui

React + FastAPI snap to read/write two PLC symbols via ctrlX Data Layer:
- `plc/app/Application/sym/PLC_PRG/motorEnable` (Bool)
- `plc/app/Application/sym/PLC_PRG/motorSpeed` (Int)

## Local dev (no snap)
Backend:
```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
# Optionally connect to a CORE over TCP in dev:
# export DL_CONNECTION="tcp://<CORE_IP>:2069?ssl=false&auth=basic,user=<user>,password=<pass>"
uvicorn app:app --reload --port 5000
```

Frontend:
```bash
cd frontend
npm install
npm run dev -- --port 5173
```

Open http://localhost:5173

## Build snap (inside ctrlX App Build Environment)
```bash
./build_snap_amd.sh
# for arm64 hardware targets:
# snapcraft --destructive-mode --target-arch=arm64
```

Install on CORE:
```bash
sudo snap install ./ctrlx-motor-ui_1.0.0_*.snap --dangerous
```

Then open the app from the CORE sidebar.
