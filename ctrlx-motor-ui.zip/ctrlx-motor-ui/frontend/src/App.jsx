import {useEffect, useState} from "react";
import React from "react";
import { createRoot } from "react-dom/client";

function App() {
  const [busy, setBusy] = useState(false);
  const [motorEnable, setMotorEnable] = useState(false);
  const [motorSpeed, setMotorSpeed] = useState(0);
  const [err, setErr] = useState("");

  const api = (path) => fetch(path, {headers: {"Content-Type": "application/json"}});

  const load = async () => {
    setBusy(true); setErr("");
    try {
      const r = await api("/api/state");
      if (!r.ok) throw new Error(await r.text());
      const j = await r.json();
      setMotorEnable(j.motorEnable);
      setMotorSpeed(j.motorSpeed);
    } catch (e) { setErr(String(e)); }
    setBusy(false);
  };

  const save = async () => {
    setBusy(true); setErr("");
    try {
      const r = await fetch("/api/state", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({motorEnable, motorSpeed: Number(motorSpeed)})
      });
      if (!r.ok) throw new Error(await r.text());
      const j = await r.json();
      setMotorEnable(j.motorEnable);
      setMotorSpeed(j.motorSpeed);
    } catch (e) { setErr(String(e)); }
    setBusy(false);
  };

  useEffect(() => { load(); }, []);

  return (
    <div style={{fontFamily:"Inter,system-ui", padding:"1.25rem", maxWidth: 560}}>
      <h1>Motor Control</h1>
      <label style={{display:"flex", gap:12, alignItems:"center"}}>
        <input type="checkbox"
               checked={motorEnable}
               onChange={e => setMotorEnable(e.target.checked)} />
        <span>Enable</span>
      </label>

      <div style={{marginTop: 16}}>
        <label>Speed</label>
        <input type="number"
               min={0} max={10000}
               value={motorSpeed}
               onChange={e=>setMotorSpeed(e.target.value)}
               style={{display:"block", width:160, padding:"6px 8px"}} />
      </div>

      <div style={{display:"flex", gap:12, marginTop:16}}>
        <button onClick={load} disabled={busy}>Refresh</button>
        <button onClick={save} disabled={busy}>Apply</button>
      </div>

      {busy && <p>Working…</p>}
      {err && <p style={{color:"crimson"}}>{err}</p>}
    </div>
  );
}

const root = createRoot(document.getElementById("root"));
root.render(<App />);
